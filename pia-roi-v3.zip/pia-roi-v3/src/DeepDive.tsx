import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { CalculatorInputs, AgencyProfile } from './types';
import { DEFAULTS, calculateRoomStats } from './constants';
import { formatCurrency } from './calculations';
import { FileText, Settings2 } from 'lucide-react';

const inputStyle: React.CSSProperties = {
  width: '100%',
  height: 42,
  padding: '0 12px',
  background: 'var(--bg)',
  border: '1px solid var(--border)',
  borderRadius: 'var(--radius)',
  color: 'var(--text)',
  fontSize: 14,
  fontFamily: 'var(--font-body)',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 11,
  fontWeight: 600,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--text-muted)',
  marginBottom: 6,
};

const section: React.CSSProperties = {
  borderTop: '1px solid var(--border)',
  paddingTop: 28,
  marginTop: 28,
};

export const DeepDive: React.FC = () => {
  const navigate = useNavigate();
  const [inputs, setInputs] = useState<CalculatorInputs | null>(null);
  const [showCosts, setShowCosts] = useState(false);
  const [loading, setLoading] = useState(false);

  const [profile, setProfile] = useState<AgencyProfile>({
    departmentName: '',
    city: '',
    state: '',
    contactName: '',
    contactTitle: '',
    decisionTimeline: '30-90 days',
    biggestPressure: 'Turnover',
  });

  useEffect(() => {
    const saved = localStorage.getItem('roi_inputs');
    if (saved) {
      const parsed = JSON.parse(saved);

      // Ensure replacement cost uses new field name
      if (!parsed.replacementCostPerPerson) {
        parsed.replacementCostPerPerson = parsed.recruitCost > 20000 ? parsed.recruitCost : DEFAULTS.REPLACEMENT_COST;
      }

      // Ensure turnoverRatePct
      if (!parsed.turnoverRatePct && parsed.annualTurnoverCount && parsed.headcount) {
        parsed.turnoverRatePct = parseFloat(((parsed.annualTurnoverCount / parsed.headcount) * 100).toFixed(1));
      }
      if (!parsed.turnoverRatePct) parsed.turnoverRatePct = DEFAULTS.TURNOVER_RATE;

      // Room costs
      const rooms = calculateRoomStats(parsed.headcount);
      if (!parsed.pilotCapex) parsed.pilotCapex = rooms.pilotCapex;
      if (!parsed.pilotRoomOpexAnnual) parsed.pilotRoomOpexAnnual = rooms.pilotRoomOpexAnnual;
      if (!parsed.appCostPerUserPerMonth) parsed.appCostPerUserPerMonth = DEFAULTS.APP_COST_PER_USER_MONTHLY;
      if (parsed.includeAppCost === undefined) parsed.includeAppCost = true;

      setInputs(parsed);
    }

    const savedProfile = localStorage.getItem('roi_profile');
    if (savedProfile) setProfile(JSON.parse(savedProfile));
  }, []);

  const setField = (field: keyof CalculatorInputs, value: unknown) => {
    if (!inputs) return;
    setInputs({ ...inputs, [field]: value });
  };

  const setProfileField = (field: keyof AgencyProfile, value: string) => {
    const updated = { ...profile, [field]: value };
    setProfile(updated);
    localStorage.setItem('roi_profile', JSON.stringify(updated));
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputs) return;
    setLoading(true);
    const finalInputs: CalculatorInputs = { ...inputs, profile };
    localStorage.setItem('roi_inputs', JSON.stringify(finalInputs));
    setTimeout(() => {
      setLoading(false);
      navigate('/council-report');
    }, 600);
  };

  if (!inputs) return <div style={{ padding: 80, textAlign: 'center', color: 'var(--text-muted)' }}>Loading...</div>;

  const numRooms = calculateRoomStats(inputs.headcount).numRooms;
  const annualAppCost = inputs.includeAppCost ? inputs.headcount * (inputs.appCostPerUserPerMonth || 15) * 12 : 0;
  const totalAnnualCost = (inputs.pilotRoomOpexAnnual || 0) + annualAppCost;

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '48px 24px' }} className="animate-fade-up">

      <div style={{ textAlign: 'center', marginBottom: 36 }}>
        <FileText size={32} color="var(--accent-bright)" style={{ marginBottom: 12 }} />
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, color: 'var(--text)', marginBottom: 8 }}>
          Finalize Council Report
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
          Add department details to generate a PDF the chief can hand to finance.
        </p>
      </div>

      <form onSubmit={handleGenerate}>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 6, padding: 32 }}>

          {/* Section 1: Tune the numbers */}
          <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20 }}>
            1 — Operational Inputs
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            <div>
              <label style={labelStyle}>Annual Turnover Rate (%)</label>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input
                  type="number"
                  step="0.1"
                  style={inputStyle}
                  value={inputs.turnoverRatePct || 12}
                  onChange={e => setField('turnoverRatePct', parseFloat(e.target.value))}
                />
                <span style={{ fontSize: 11, color: 'var(--text-dim)', whiteSpace: 'nowrap' }}>
                  ~{Math.round(inputs.headcount * ((inputs.turnoverRatePct || 12) / 100))} people/yr
                </span>
              </div>
            </div>
            <div>
              <label style={labelStyle}>Replacement Cost / Person ($)</label>
              <input
                type="number"
                style={inputStyle}
                value={inputs.replacementCostPerPerson || DEFAULTS.REPLACEMENT_COST}
                onChange={e => setField('replacementCostPerPerson', parseFloat(e.target.value))}
              />
              <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 3 }}>
                Default $175K — PERF benchmark (includes academy, FTO, vacancy OT)
              </p>
            </div>
          </div>

          {/* Cost tuning toggle */}
          <div style={{ marginTop: 20 }}>
            <button
              type="button"
              onClick={() => setShowCosts(!showCosts)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                background: 'none', border: 'none', cursor: 'pointer',
                color: 'var(--accent-bright)', fontSize: 11, fontWeight: 700,
                letterSpacing: '0.06em', textTransform: 'uppercase', padding: 0,
              }}
            >
              <Settings2 size={12} />
              {showCosts ? 'Hide Pilot Costs' : 'Edit Pilot Costs'}
            </button>

            {showCosts && (
              <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, padding: 16, background: 'var(--bg-raised)', borderRadius: 4 }} className="animate-fade-in">
                <div style={{ gridColumn: '1 / -1', fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>
                  Estimated: {numRooms} room{numRooms > 1 ? 's' : ''} for {inputs.headcount} staff
                </div>
                <div>
                  <label style={labelStyle}>Room Hardware + Install (CapEx)</label>
                  <input type="number" style={inputStyle} value={inputs.pilotCapex}
                    onChange={e => setField('pilotCapex', parseFloat(e.target.value))} />
                  <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 3 }}>{formatCurrency(DEFAULTS.ROOM_CAPEX)}/room</p>
                </div>
                <div>
                  <label style={labelStyle}>Annual Room Service (OpEx)</label>
                  <input type="number" style={inputStyle} value={inputs.pilotRoomOpexAnnual}
                    onChange={e => setField('pilotRoomOpexAnnual', parseFloat(e.target.value))} />
                  <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 3 }}>{formatCurrency(DEFAULTS.ROOM_OPEX_MONTHLY)}/mo per room</p>
                </div>
                {inputs.includeAppCost && (
                  <div>
                    <label style={labelStyle}>App Cost / User / Month ($)</label>
                    <input type="number" style={inputStyle} value={inputs.appCostPerUserPerMonth || 15}
                      onChange={e => setField('appCostPerUserPerMonth', parseFloat(e.target.value))} />
                    <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 3 }}>
                      = ${annualAppCost.toLocaleString()}/yr for {inputs.headcount} users
                    </p>
                  </div>
                )}
                <div style={{ gridColumn: '1 / -1', padding: '10px 0', borderTop: '1px solid var(--border)', fontSize: 12, color: 'var(--text-muted)' }}>
                  Total annual cost (Year 2+): <strong style={{ color: 'var(--text)' }}>${totalAnnualCost.toLocaleString()}</strong>
                </div>
              </div>
            )}
          </div>

          {/* Section 2: Department */}
          <div style={section}>
            <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20 }}>
              2 — Department Info
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={labelStyle}>Full Department Name</label>
                <input required placeholder="e.g. Glendale Police Department" style={inputStyle}
                  value={profile.departmentName} onChange={e => setProfileField('departmentName', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>City</label>
                <input required placeholder="e.g. Glendale" style={inputStyle}
                  value={profile.city} onChange={e => setProfileField('city', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>State (2-letter)</label>
                <input required placeholder="AZ" maxLength={2} style={inputStyle}
                  value={profile.state} onChange={e => setProfileField('state', e.target.value.toUpperCase())} />
              </div>
            </div>
          </div>

          {/* Section 3: Contact */}
          <div style={section}>
            <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20 }}>
              3 — Contact
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={labelStyle}>Name</label>
                <input required style={inputStyle}
                  value={profile.contactName} onChange={e => setProfileField('contactName', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>Title / Rank</label>
                <input required placeholder="e.g. Chief of Police" style={inputStyle}
                  value={profile.contactTitle} onChange={e => setProfileField('contactTitle', e.target.value)} />
              </div>
            </div>
          </div>

          {/* Section 4: Context */}
          <div style={section}>
            <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20 }}>
              4 — Strategic Context (Optional)
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={labelStyle}>Primary Pressure Point</label>
                <select style={inputStyle} value={profile.biggestPressure}
                  onChange={e => setProfileField('biggestPressure', e.target.value)}>
                  <option value="Turnover">Turnover / Recruiting</option>
                  <option value="Overtime">Overtime / Budget Bleed</option>
                  <option value="Workers Comp">Workers Comp</option>
                  <option value="Liability">Liability / Risk</option>
                  <option value="Sleep/Readiness">Sleep / Operational Readiness</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>Decision Timeline</label>
                <select style={inputStyle} value={profile.decisionTimeline}
                  onChange={e => setProfileField('decisionTimeline', e.target.value as AgencyProfile['decisionTimeline'])}>
                  <option value="0-30 days">Immediate (0-30 days)</option>
                  <option value="30-90 days">Next Budget Cycle (30-90 days)</option>
                  <option value="90+ days">Long-term Planning</option>
                </select>
              </div>
            </div>
          </div>

          {/* Submit */}
          <div style={{ marginTop: 32 }}>
            <Button size="xl" type="submit" disabled={loading} style={{ width: '100%' }}>
              {loading ? 'Generating Report...' : 'Generate Full Council Report →'}
            </Button>
            <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-dim)', marginTop: 8 }}>
              Department data is not sold or shared.
            </p>
          </div>

        </div>
      </form>
    </div>
  );
};
