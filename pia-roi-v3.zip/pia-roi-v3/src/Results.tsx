import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { CalculatorInputs, RiskMode } from './types';
import { calculateROI, formatCurrency, formatCurrencyFull } from './calculations';
import { FileText, ArrowRight, TrendingDown } from 'lucide-react';

const card: React.CSSProperties = {
  background: 'var(--bg-surface)',
  border: '1px solid var(--border)',
  borderRadius: 4,
  padding: '20px 24px',
};

export const Results: React.FC = () => {
  const navigate = useNavigate();
  const [mode, setMode] = useState<RiskMode>(RiskMode.CONSERVATIVE);
  const [inputs, setInputs] = useState<CalculatorInputs | null>(null);
  const [sliderValue, setSliderValue] = useState(650);

  useEffect(() => {
    const saved = localStorage.getItem('roi_inputs');
    if (saved) {
      const parsed = JSON.parse(saved);
      setInputs(parsed);
      setSliderValue(parsed.liabilityCostPerHead || 650);
    } else {
      navigate('/quick');
    }
  }, [navigate]);

  const handleSlider = (val: number) => {
    setSliderValue(val);
    if (inputs) {
      const updated = { ...inputs, liabilityCostPerHead: val };
      setInputs(updated);
      localStorage.setItem('roi_inputs', JSON.stringify(updated));
    }
  };

  if (!inputs) return <div style={{ padding: 80, textAlign: 'center', color: 'var(--text-muted)' }}>Loading...</div>;

  const results = calculateROI(inputs, mode);
  const modeColors = { Conservative: '#10b981', Standard: 'var(--accent-bright)', Aggressive: '#f59e0b' };

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '48px 24px' }} className="animate-fade-up">

      {/* Header */}
      <div style={{ marginBottom: 40 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
          <div>
            <p style={{ fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 6, fontWeight: 600 }}>
              Estimated Annual Avoidable Loss
            </p>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 52, fontWeight: 800, color: 'var(--text)', lineHeight: 1 }}>
              {formatCurrency(results.totalAnnualSavings)}
              <span style={{ fontSize: 18, fontFamily: 'var(--font-body)', fontWeight: 400, color: 'var(--text-muted)', marginLeft: 8 }}>/yr</span>
            </div>
          </div>

          {/* Mode toggle */}
          <div style={{ display: 'flex', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 4, overflow: 'hidden' }}>
            {Object.values(RiskMode).map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                style={{
                  padding: '8px 16px',
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                  border: 'none',
                  cursor: 'pointer',
                  background: mode === m ? modeColors[m] : 'transparent',
                  color: mode === m ? '#fff' : 'var(--text-dim)',
                  transition: 'all 0.15s',
                }}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Cost context */}
        <div style={{ marginTop: 12, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Year 1 investment: <strong style={{ color: 'var(--text)' }}>{formatCurrency(results.year1TotalCost)}</strong>
          </span>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Payback: <strong style={{ color: 'var(--accent-bright)' }}>{results.paybackMonths} months</strong>
          </span>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            5-year net: <strong style={{ color: 'var(--green)' }}>{formatCurrency(results.fiveYearNet)}</strong>
          </span>
        </div>
      </div>

      {/* Cost Breakdown Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14, marginBottom: 28 }}>
        <ResultCard title="Turnover Drag" value={results.turnoverDrag}
          desc={`${Math.round(inputs.headcount * (inputs.turnoverRatePct || 12) / 100)} separations × $${(inputs.replacementCostPerPerson || 175000).toLocaleString()} replacement cost`} />
        <ResultCard title="Overtime Inefficiency" value={results.overtimeDrag}
          desc={`${mode === RiskMode.CONSERVATIVE ? '5%' : mode === RiskMode.STANDARD ? '10%' : '15%'} recoverable via fatigue reduction`} />
        <ResultCard title="Workers Comp" value={results.workersCompDrag}
          desc={`${mode === RiskMode.CONSERVATIVE ? '3%' : mode === RiskMode.STANDARD ? '6%' : '10%'} claim reduction from physical recovery programs`} />

        {/* Liability with slider */}
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <h4 style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>Liability Drag</h4>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 600, color: 'var(--text)' }}>
              {formatCurrency(results.liabilityDrag)}
            </span>
          </div>
          <p style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 14 }}>
            Estimated settlements & misconduct payouts based on headcount.
          </p>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>
              <span>Conservative</span>
              <span style={{ color: 'var(--accent-bright)', fontWeight: 600 }}>${sliderValue.toLocaleString()}/officer</span>
              <span>Aggressive</span>
            </div>
            <input type="range" min={0} max={15000} step={100} value={sliderValue}
              onChange={e => handleSlider(Number(e.target.value))}
              style={{ width: '100%', accentColor: 'var(--accent)' }}
            />
          </div>
        </div>
      </div>

      {/* Performance note if applicable */}
      {results.performanceDrag > 0 && (
        <div style={{
          padding: '10px 16px', marginBottom: 20,
          background: 'var(--bg-raised)', border: '1px solid var(--border)',
          borderLeft: '3px solid var(--accent-dim)', borderRadius: 4,
          fontSize: 12, color: 'var(--text-muted)',
        }}>
          <TrendingDown size={12} style={{ display: 'inline', marginRight: 6 }} />
          <strong style={{ color: 'var(--text)' }}>Performance drag included: {formatCurrency(results.performanceDrag)}</strong> — estimated fatigue-related absenteeism and errors.
          When real OT/WC data is entered, this is excluded to avoid double-counting.
        </div>
      )}

      {/* 5-Year Table */}
      <div style={{ ...card, marginBottom: 28 }}>
        <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 16 }}>
          5-Year Budget Projection
        </h3>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Year', 'Gross Savings', 'Total Cost', 'Net Benefit', 'Cumulative Net'].map(h => (
                  <th key={h} style={{ padding: '8px 12px', textAlign: 'right', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-dim)', whiteSpace: 'nowrap' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.fiveYearTable.map(row => (
                <tr key={row.year} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.1s' }}>
                  <td style={{ padding: '10px 12px', textAlign: 'right', fontWeight: 700, color: 'var(--text-muted)' }}>
                    Year {row.year}{row.year === 1 ? ' *' : ''}
                  </td>
                  <td style={{ padding: '10px 12px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text)' }}>
                    {formatCurrencyFull(row.grossSavings)}
                  </td>
                  <td style={{ padding: '10px 12px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                    ({formatCurrencyFull(row.cost)})
                  </td>
                  <td style={{ padding: '10px 12px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: row.net >= 0 ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>
                    {formatCurrencyFull(row.net)}
                  </td>
                  <td style={{ padding: '10px 12px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 700, color: row.cumulative >= 0 ? 'var(--green)' : 'var(--text)' }}>
                    {formatCurrencyFull(row.cumulative)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ marginTop: 10, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <p style={{ fontSize: 11, color: 'var(--text-dim)' }}>
            * Year 1 includes ${formatCurrency(results.pilotCapex)} one-time hardware/install
          </p>
          {inputs.includeAppCost && (
            <p style={{ fontSize: 11, color: 'var(--text-dim)' }}>
              App cost: ${(inputs.headcount * 15 * 12).toLocaleString()}/yr included in all years
            </p>
          )}
        </div>
      </div>

      {/* Cost Breakdown */}
      <div style={{ ...card, marginBottom: 28 }}>
        <h3 style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 14 }}>
          Investment Breakdown
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12 }}>
          <CostLine label={`Room Hardware + Install (${results.numRooms} rooms)`} value={results.pilotCapex} note="One-time" />
          <CostLine label={`Room Service/Support`} value={results.roomOpexAnnual} note="Annual" />
          {inputs.includeAppCost && (
            <CostLine label={`App (${inputs.headcount} users × $15/mo)`} value={results.appCostAnnual} note="Annual" />
          )}
          <CostLine label="Total Year 1" value={results.year1TotalCost} note="All-in" highlight />
          <CostLine label="Annual (Year 2+)" value={results.annualTotalCost} note="OpEx only" />
        </div>
      </div>

      {/* CTA */}
      <div style={{
        ...card,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16,
      }}>
        <div>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', marginBottom: 4 }}>Ready for the council meeting?</h3>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Generate a PDF report with methodology, risk register, and 90-day pilot proposal.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Button variant="outline" onClick={() => navigate('/assumptions')}>
            Methodology
          </Button>
          <Button onClick={() => navigate('/deep-dive')}>
            Generate Full Report <ArrowRight size={14} style={{ marginLeft: 6 }} />
          </Button>
        </div>
      </div>
    </div>
  );
};

const ResultCard: React.FC<{ title: string; value: number; desc: string }> = ({ title, value, desc }) => (
  <div style={{
    background: 'var(--bg-surface)',
    border: '1px solid var(--border)',
    borderRadius: 4,
    padding: '20px 24px',
  }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
      <h4 style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{title}</h4>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 600, color: 'var(--text)' }}>{formatCurrency(value)}</span>
    </div>
    <p style={{ fontSize: 11, color: 'var(--text-dim)', lineHeight: 1.5 }}>{desc}</p>
  </div>
);

const CostLine: React.FC<{ label: string; value: number; note: string; highlight?: boolean }> = ({ label, value, note, highlight }) => (
  <div style={{
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '8px 0',
    borderBottom: highlight ? 'none' : '1px solid var(--border)',
    borderTop: highlight ? '1px solid var(--border)' : 'none',
    marginTop: highlight ? 4 : 0,
  }}>
    <div>
      <span style={{ fontSize: 12, color: highlight ? 'var(--text)' : 'var(--text-muted)', fontWeight: highlight ? 700 : 400 }}>{label}</span>
      <span style={{ display: 'block', fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{note}</span>
    </div>
    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: highlight ? 700 : 500, color: highlight ? 'var(--text)' : 'var(--text-muted)' }}>
      {formatCurrencyFull(value)}
    </span>
  </div>
);
