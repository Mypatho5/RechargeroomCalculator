import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './Layout';
import { QuickCalc } from './QuickCalc';
import { Results } from './Results';
import { DeepDive } from './DeepDive';
import { CouncilReport } from './CouncilReport';
import { Assumptions } from './Assumptions';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/quick" replace />} />
          <Route path="quick" element={<QuickCalc />} />
          <Route path="results" element={<Results />} />
          <Route path="deep-dive" element={<DeepDive />} />
          <Route path="council-report" element={<CouncilReport />} />
          <Route path="assumptions" element={<Assumptions />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
