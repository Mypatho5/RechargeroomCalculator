import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { EVIDENCE, MULTIPLIERS, DEFAULTS } from './constants';
import { ExternalLink, ArrowLeft, Scale, Calculator, ShieldCheck, AlertTriangle } from 'lucide-react';

export const Assumptions: React.FC = () => {
  const navigate = useNavigate();

  const h2Style: React.CSSProperties = {
    fontSize: 20,
    fontWeight: 700,
    color: 'var(--text)',
    marginBottom: 6,
    display: 'flex',
    alignItems: 'center',
    gap: 10,
  };

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', padding: '48px 24px' }} className="animate-fade-up">

      <div style={{ marginBottom: 36, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft size={13} style={{ marginRight: 6 }} /> Back
        </Button>
        <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-dim)', letterSpacing: '0.06em' }}>
          METHODOLOGY v3
        </span>
      </div>

      <div style={{ marginBottom: 48 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 36, fontWeight: 800, color: 'var(--text)', marginBottom: 12 }}>
          The math is transparent by design.
        </h1>
        <p style={{ fontSize: 16, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 640 }}>
          This calculator is built to survive a city finance director. Every number is traceable to a source.
          We use multipliers that are deliberately below the academic average — because conservative math that holds up
          is worth more than aggressive math that gets torn apart in a meeting.
        </p>
      </div>

      {/* Philosophy */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 56 }}>
        {[
          { icon: <Scale size={22} color="var(--accent-bright)" />, title: 'Conservative by Default', desc: `If a study shows 20% productivity loss from fatigue, we model ${MULTIPLIERS.PRODUCTIVITY_LOSS.CONSERVATIVE * 100}%. We treat every assumption as a floor, not a ceiling.` },
          { icon: <Calculator size={22} color="var(--accent-bright)" />, title: 'Linear Math Only', desc: 'No black-box models. Cost = Count × Severity × Risk_Factor. Trace every output penny-for-penny from the input.' },
          { icon: <ShieldCheck size={22} color="var(--accent-bright)" />, title: 'Public Safety Data First', desc: 'BJS, PERF, NFPA, NCCI — not generic corporate wellness studies. The sources are relevant to the audience.' },
        ].map(c => (
          <div key={c.title} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: '20px 22px' }}>
            <div style={{ marginBottom: 12 }}>{c.icon}</div>
            <h3 style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 8, fontSize: 14 }}>{c.title}</h3>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.6 }}>{c.desc}</p>
          </div>
        ))}
      </div>

      {/* Driver 1: Turnover */}
      <section style={{ marginBottom: 48 }}>
        <h2 style={h2Style}>1. Turnover & Separation Cost</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>
          Default: <strong style={{ color: 'var(--accent-bright)' }}>${DEFAULTS.REPLACEMENT_COST.toLocaleString()} per officer</strong> — PERF midpoint, below the $250K ceiling
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 20, fontSize: 13 }}>
            <h4 style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>What's counted</h4>
            <ul style={{ color: 'var(--text-muted)', paddingLeft: 16, lineHeight: 2 }}>
              <li>Recruitment advertising + background checks</li>
              <li>Academy tuition + gear</li>
              <li>Field Training Officer (FTO) overlap time</li>
              <li>Vacancy drag — OT paid to backfill the empty seat</li>
              <li>Administrative separation costs</li>
              <li>18–24 month ramp to full solo patrol capability</li>
            </ul>
          </div>
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 20, fontSize: 13 }}>
            <h4 style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>Why $175K is defensible</h4>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.7 }}>
              PERF 2019 puts sworn officer replacement at $150K–$250K. SHRM and Police Chief Magazine
              cite 150%–200% of annual salary. At $120K base, that's $180K–$240K.
              We use $175K — below PERF's midpoint — so no one can accuse the department of inflating the number.
            </p>
            <div style={{ marginTop: 12, padding: '8px 12px', background: 'var(--bg-raised)', borderRadius: 3, fontSize: 11, color: 'var(--text-dim)' }}>
              Default turnover rate: <strong style={{ color: 'var(--text)' }}>{DEFAULTS.TURNOVER_RATE}%</strong> — BJS LEMAS municipal PD median
            </div>
          </div>
        </div>
      </section>

      {/* Driver 2: OT */}
      <section style={{ marginBottom: 48 }}>
        <h2 style={h2Style}>2. Overtime Inefficiency</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>
          Recovery claimed: <strong style={{ color: 'var(--accent-bright)' }}>{MULTIPLIERS.OVERTIME_SAVINGS.CONSERVATIVE * 100}%–{MULTIPLIERS.OVERTIME_SAVINGS.AGGRESSIVE * 100}% of OT spend</strong>
        </p>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 20, fontSize: 13 }}>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 12 }}>
            We don't claim all OT is bad — minimum staffing requires it. What we model is the
            <strong style={{ color: 'var(--text)' }}> sick-call-driven OT loop</strong>: fatigued officers call out sick → other officers
            cover on OT → those officers get fatigued → loop repeats.
          </p>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 12 }}>
            RAND Corporation police staffing research shows burnout intervention reduces OT dependency by 8–15%.
            We claim 5–15% depending on scenario — the conservative end is well below the evidence.
          </p>
          <div style={{ padding: '10px 14px', background: 'var(--bg-raised)', borderRadius: 3, fontSize: 11, color: 'var(--text-dim)', borderLeft: '3px solid var(--accent-dim)' }}>
            <strong style={{ color: 'var(--text)' }}>Estimation note:</strong> When no OT figure is entered, the model estimates at {DEFAULTS.OT_ESTIMATE_PCT * 100}% of payroll — BJS LEMAS municipal median.
            Enter your actual OT spend for a tighter number.
          </div>
        </div>
      </section>

      {/* Driver 3: Workers Comp */}
      <section style={{ marginBottom: 48 }}>
        <h2 style={h2Style}>3. Workers Compensation</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>
          Recovery claimed: <strong style={{ color: 'var(--accent-bright)' }}>{MULTIPLIERS.COMP_REDUCTION.CONSERVATIVE * 100}%–{MULTIPLIERS.COMP_REDUCTION.AGGRESSIVE * 100}% of WC spend</strong>
        </p>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 20, fontSize: 13 }}>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 12 }}>
            NCCI class code 7720 (Police Officers) carries a base rate of 4–8% of payroll before
            experience modification. When no actual WC figure is provided, the model estimates at <strong style={{ color: 'var(--text)' }}>{DEFAULTS.WC_ESTIMATE_PCT * 100}% of payroll</strong>.
          </p>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7 }}>
            Evidence-based physical recovery programs (Vimocity protocols) show 3–10% claim reduction in published studies.
            We use 3–10% depending on scenario — bottom of the range is well inside the evidence.
          </p>
        </div>
      </section>

      {/* Driver 4: Liability */}
      <section style={{ marginBottom: 48 }}>
        <h2 style={h2Style}>4. Liability Exposure</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>
          Model: <strong style={{ color: 'var(--accent-bright)' }}>per-officer risk annualized</strong> — adjustable via slider
        </p>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 20, fontSize: 13 }}>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 12 }}>
            Liability is "lumpy" — one bad year costs millions, the next costs nothing. We smooth this by assigning
            an annualized per-officer risk value based on jurisdiction type.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 12 }}>
            {[
              { label: 'Major City', value: '$8,000/officer', note: 'Based on Chicago PD settlement history' },
              { label: 'Suburb', value: '$650/officer', note: 'Based on mid-size municipal average' },
              { label: 'Rural', value: '$350/officer', note: 'Based on PERF rural settlement data' },
            ].map(item => (
              <div key={item.label} style={{ padding: '10px 14px', background: 'var(--bg-raised)', borderRadius: 3 }}>
                <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.07em', color: 'var(--text-dim)', marginBottom: 4 }}>{item.label}</div>
                <div style={{ fontWeight: 700, color: 'var(--text)' }}>{item.value}</div>
                <div style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 2 }}>{item.note}</div>
              </div>
            ))}
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.6 }}>
            Trauma-informed leadership training and de-escalation culture have documented reduction in use-of-force incidents
            and subsequent liability exposure. The slider lets the chief or finance director adjust this to their actual settlement history.
          </p>
        </div>
      </section>

      {/* Performance drag explanation */}
      <section style={{ marginBottom: 48 }}>
        <h2 style={h2Style}>
          <AlertTriangle size={20} color="var(--yellow)" />
          Performance Drag — When It's Included
        </h2>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderLeft: '3px solid var(--yellow)', borderRadius: 4, padding: 20, fontSize: 13 }}>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7 }}>
            Performance and absenteeism drag (fatigue-related errors, sick call usage) is modeled at {MULTIPLIERS.PRODUCTIVITY_LOSS.CONSERVATIVE * 100}%–{MULTIPLIERS.PRODUCTIVITY_LOSS.AGGRESSIVE * 100}% of payroll.
            <strong style={{ color: 'var(--text)' }}> It is only included when no real OT or WC data has been entered.</strong>
          </p>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginTop: 8 }}>
            Why: Fatigue-driven sick calls and performance degradation are already embedded in OT and WC costs.
            If you have those real numbers, performance drag is already counted. Including it again would double-count
            and inflate the figure — which is the opposite of what a council presentation needs.
          </p>
        </div>
      </section>

      {/* Evidence Library */}
      <section>
        <h2 style={{ ...h2Style, marginBottom: 20 }}>Evidence Library</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {EVIDENCE.map(item => (
            <div key={item.id} style={{
              background: 'var(--bg-surface)', border: '1px solid var(--border)',
              borderRadius: 4, padding: '14px 18px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{
                    fontSize: 9, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
                    padding: '2px 8px', background: 'rgba(37,99,235,0.1)', color: 'var(--accent-bright)',
                    borderRadius: 2,
                  }}>{item.category}</span>
                </div>
                <h4 style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', marginBottom: 3 }}>{item.title}</h4>
                <p style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>{item.source}</p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5, fontStyle: 'italic' }}>{item.finding}</p>
              </div>
              <a href={item.url} target="_blank" rel="noopener noreferrer"
                style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 600, color: 'var(--text-dim)', textDecoration: 'none', whiteSpace: 'nowrap', flexShrink: 0 }}>
                Verify <ExternalLink size={11} />
              </a>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
