import React from 'react';
import { Outlet, useLocation, Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';

const steps = [
  { path: '/quick', label: 'Input' },
  { path: '/results', label: 'Results' },
  { path: '/deep-dive', label: 'Refine' },
  { path: '/council-report', label: 'Report' },
];

export const Layout: React.FC = () => {
  const { pathname } = useLocation();
  const isReport = pathname === '/council-report';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Nav */}
      <nav style={{
        borderBottom: '1px solid var(--border)',
        background: 'var(--bg)',
        padding: '0 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 56,
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }} className="no-print">
        <Link to="/quick" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
          <ShieldCheck size={18} color="var(--accent-bright)" />
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 800, color: 'var(--text)', letterSpacing: '0.05em' }}>
            PIA<span style={{ color: 'var(--accent-bright)' }}>ROI</span>
          </span>
        </Link>

        {!isReport && (
          <div style={{ display: 'flex', gap: 4 }}>
            {steps.map((s, i) => {
              const active = pathname === s.path;
              return (
                <span key={s.path} style={{
                  padding: '4px 12px',
                  borderRadius: 2,
                  fontSize: 11,
                  fontWeight: 600,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: active ? 'var(--text)' : 'var(--text-dim)',
                  background: active ? 'var(--bg-raised)' : 'transparent',
                  border: `1px solid ${active ? 'var(--border-bright)' : 'transparent'}`,
                }}>
                  {i + 1}. {s.label}
                </span>
              );
            })}
          </div>
        )}

        <Link to="/assumptions" style={{
          fontSize: 11,
          color: 'var(--text-dim)',
          textDecoration: 'none',
          letterSpacing: '0.05em',
          textTransform: 'uppercase',
          fontWeight: 600,
        }}>
          Methodology
        </Link>
      </nav>

      {/* Content */}
      <main style={{ flex: 1 }}>
        <Outlet />
      </main>

      {/* Footer */}
      {!isReport && (
        <footer style={{
          borderTop: '1px solid var(--border)',
          padding: '16px 24px',
          textAlign: 'center',
          fontSize: 11,
          color: 'var(--text-dim)',
        }} className="no-print">
          PIA ROI Calculator — Estimates only. Not legal or actuarial advice. &nbsp;|&nbsp;
          <Link to="/assumptions" style={{ color: 'var(--accent-bright)', textDecoration: 'none' }}>View Full Methodology</Link>
        </footer>
      )}
    </div>
  );
};
