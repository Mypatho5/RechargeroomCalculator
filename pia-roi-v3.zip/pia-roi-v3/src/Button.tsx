import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  style,
  ...props
}) => {
  const base: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-body)',
    fontWeight: 600,
    letterSpacing: '0.03em',
    cursor: 'pointer',
    border: '1px solid transparent',
    borderRadius: 'var(--radius)',
    transition: 'all 0.15s ease',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
  };

  const sizes: Record<string, React.CSSProperties> = {
    sm:  { padding: '6px 14px',  fontSize: 12 },
    md:  { padding: '9px 20px',  fontSize: 13 },
    lg:  { padding: '11px 28px', fontSize: 14 },
    xl:  { padding: '14px 32px', fontSize: 15 },
  };

  const variants: Record<string, React.CSSProperties> = {
    primary:   { background: 'var(--accent)', color: '#fff', borderColor: 'var(--accent)' },
    secondary: { background: 'var(--bg-raised)', color: 'var(--text)', borderColor: 'var(--border-bright)' },
    outline:   { background: 'transparent', color: 'var(--text-muted)', borderColor: 'var(--border)' },
    ghost:     { background: 'transparent', color: 'var(--text-muted)', borderColor: 'transparent' },
  };

  return (
    <button
      style={{ ...base, ...sizes[size], ...variants[variant], ...style }}
      {...props}
    >
      {children}
    </button>
  );
};
