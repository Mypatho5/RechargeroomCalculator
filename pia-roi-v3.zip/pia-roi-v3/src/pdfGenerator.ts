import jsPDF from 'jspdf';
import { CalculatorInputs, CalculationResult, RiskMode } from './types';
import { formatCurrency, formatCurrencyFull } from './calculations';
import { DEFAULTS, MULTIPLIERS } from './constants';

export const generateCouncilReport = (
  inputs: CalculatorInputs,
  results: CalculationResult,
  mode: RiskMode
) => {
  const doc = new jsPDF();
  let y = 20;
  const margin = 18;
  const pageWidth = 210;
  const contentWidth = pageWidth - margin * 2;
  const pageHeight = 290;

  const br = (h = 8) => { y += h; };

  const checkBreak = (needed = 12) => {
    if (y + needed > pageHeight - margin) { doc.addPage(); y = 20; }
  };

  const heading = (text: string, size = 13) => {
    checkBreak(size + 8);
    doc.setFontSize(size);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(10, 10, 30);
    doc.text(text, margin, y);
    y += size * 0.55 + 2;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(60, 60, 80);
  };

  const rule = (color: [number, number, number] = [210, 210, 220]) => {
    doc.setDrawColor(...color);
    doc.line(margin, y, margin + contentWidth, y);
    br(6);
  };

  const small = (text: string, color: [number, number, number] = [120, 120, 140]) => {
    doc.setFontSize(8.5);
    doc.setTextColor(...color);
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 4.5;
  };

  // ---- HEADER ----
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(10, 20, 60);
  doc.text('Fiscal Impact & Readiness Brief', margin, y); br(8);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 100);
  const dept = inputs.profile?.departmentName || `${inputs.agencyType} Agency`;
  doc.text(`Prepared for: ${dept}`, margin, y);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, pageWidth - margin - 36, y); br(5);
  if (inputs.profile?.city) {
    doc.text(`Jurisdiction: ${inputs.profile.city}, ${inputs.profile.state}`, margin, y); br(5);
  }
  doc.text(`Analysis Mode: ${mode} | Primary Driver: ${results.primaryDriver}`, margin, y); br(10);
  rule([180, 180, 200]);

  // ---- 1. DECISION ASK ----
  heading('1. Decision Request', 13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0);
  doc.text(`APPROVE: ${inputs.pilotDurationDays || 90}-Day Readiness Pilot — ${results.numRooms} Recharge Unit${results.numRooms > 1 ? 's' : ''}${inputs.includeAppCost ? ' + Platform Access' : ''}`, margin, y); br(6);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 60, 80);
  const summary = `Based on a headcount of ${inputs.headcount}, this analysis identifies ${formatCurrency(results.totalAnnualSavings)} in estimated annual avoidable costs — primarily driven by ${results.primaryDriver.toLowerCase()}. The proposed pilot mitigates these losses at ${formatCurrency(results.year1TotalCost)} Year 1, with CapEx payback in approximately ${results.paybackMonths} months.`;
  small(summary, [50, 50, 70]); br(4);
  rule();

  // ---- 2. FINANCIAL SUMMARY ----
  heading('2. Financial Analysis', 13);

  // Three-column summary
  const c1 = margin, c2 = margin + 60, c3 = margin + 120;
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 120);
  doc.text('Annual Avoidable Loss', c1, y);
  doc.text('Year 1 Investment', c2, y);
  doc.text('CapEx Payback', c3, y); br(6);

  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0);
  doc.text(formatCurrency(results.totalAnnualSavings), c1, y);
  doc.text(formatCurrency(results.year1TotalCost), c2, y);
  doc.setTextColor(37, 99, 235);
  doc.text(`${results.paybackMonths} months`, c3, y); br(5);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(120, 120, 140);
  doc.text('Status quo annual cost', c1, y);
  doc.text('All-in including hardware', c2, y);
  doc.text(`5-yr net: ${formatCurrency(results.fiveYearNet)}`, c3, y); br(10);

  // Investment detail
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(40, 40, 60);
  doc.text('Investment Detail', margin, y); br(5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 60, 80);

  const costRows: [string, string, string][] = [
    [`Room Hardware + Install (${results.numRooms} rooms × $${DEFAULTS.ROOM_CAPEX.toLocaleString()})`, 'One-time CapEx', formatCurrencyFull(results.pilotCapex)],
    [`Room Service/Support (${results.numRooms} rooms × $${DEFAULTS.ROOM_OPEX_MONTHLY.toLocaleString()}/mo)`, 'Annual', formatCurrencyFull(results.roomOpexAnnual)],
  ];
  if (inputs.includeAppCost) {
    costRows.push([`App Platform (${inputs.headcount} users × $${inputs.appCostPerUserPerMonth || 15}/mo)`, 'Annual', formatCurrencyFull(results.appCostAnnual)]);
  }

  costRows.forEach(([label, note, val]) => {
    checkBreak(6);
    doc.setFontSize(9);
    doc.setTextColor(60, 60, 80);
    doc.text(label, margin, y);
    doc.text(note, margin + 110, y);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0);
    doc.text(val, pageWidth - margin - doc.getTextWidth(val), y);
    doc.setFont('helvetica', 'normal'); br(5);
  });

  doc.setDrawColor(180, 180, 200);
  doc.line(margin, y, margin + contentWidth, y); br(4);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Total Year 1:', margin, y);
  doc.setTextColor(37, 99, 235);
  const yr1Str = formatCurrencyFull(results.year1TotalCost);
  doc.text(yr1Str, pageWidth - margin - doc.getTextWidth(yr1Str), y); br(4);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 120);
  doc.text(`Annual cost Year 2+: ${formatCurrencyFull(results.annualTotalCost)}`, margin, y); br(10);

  // 5-Year table
  checkBreak(50);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(40, 40, 60);
  doc.text('5-Year Budget Projection', margin, y); br(5);

  const tCols = [margin, margin + 22, margin + 68, margin + 110, margin + 143];
  doc.setFontSize(8.5);
  doc.setTextColor(120, 120, 140);
  ['Year', 'Gross Savings', 'Total Cost', 'Net Benefit', 'Cumulative'].forEach((h, i) => {
    doc.text(h, tCols[i], y);
  }); br(5);

  results.fiveYearTable.forEach(row => {
    checkBreak(6);
    doc.setFont('helvetica', row.year === 1 ? 'bold' : 'normal');
    doc.setTextColor(0);
    doc.text(`Yr ${row.year}${row.year === 1 ? '*' : ''}`, tCols[0], y);
    doc.text(formatCurrencyFull(row.grossSavings), tCols[1], y);
    doc.text(`(${formatCurrencyFull(row.cost)})`, tCols[2], y);
    const netColor: [number, number, number] = row.net >= 0 ? [16, 185, 129] : [220, 50, 50];
    doc.setTextColor(...netColor);
    doc.text(formatCurrencyFull(row.net), tCols[3], y);
    const cumColor: [number, number, number] = row.cumulative >= 0 ? [16, 185, 129] : [100, 100, 120];
    doc.setTextColor(...cumColor);
    doc.setFont('helvetica', 'bold');
    doc.text(formatCurrencyFull(row.cumulative), tCols[4], y); br(5);
  });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(130, 130, 150);
  doc.text('* Year 1 includes one-time CapEx. Net = Gross Savings − Total Cost.', margin, y); br(10);
  rule();

  // ---- 3. SENSITIVITY ----
  checkBreak(50);
  heading('3. Sensitivity Analysis', 13);

  const sCols = [margin, margin + 36, margin + 84, margin + 120, margin + 148];
  doc.setFontSize(8.5);
  doc.setTextColor(120, 120, 140);
  ['Scenario', 'Annual Savings', 'Year 1 Net', 'CapEx Payback', '1-Yr ROI †'].forEach((h, i) => doc.text(h, sCols[i], y)); br(5);

  [results.sensitivity.conservative, results.sensitivity.standard, results.sensitivity.aggressive].forEach(row => {
    checkBreak(7);
    const isSel = row.mode === mode;
    doc.setFont('helvetica', isSel ? 'bold' : 'normal');
    doc.setTextColor(isSel ? 0 : 70, isSel ? 0 : 70, isSel ? 0 : 90);
    doc.text(row.mode + (isSel ? ' ✓' : ''), sCols[0], y);
    doc.text(formatCurrency(row.totalAnnualSavings), sCols[1], y);
    doc.setTextColor(16, 120, 80);
    doc.text(formatCurrency(row.netBenefit), sCols[2], y);
    doc.setTextColor(60, 60, 80);
    doc.text(`${row.paybackMonths} mo`, sCols[3], y);
    doc.text(`${row.roiPct.toFixed(0)}%`, sCols[4], y); br(6);
  });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(130, 130, 150);
  doc.text('† 1-Yr ROI = (Year 1 Net Benefit) ÷ (Year 1 Total Investment) × 100. Not annualized.', margin, y); br(4);
  doc.text(`Conservative: ${MULTIPLIERS.OVERTIME_SAVINGS.CONSERVATIVE * 100}% OT / ${MULTIPLIERS.COMP_REDUCTION.CONSERVATIVE * 100}% WC  |  Standard: ${MULTIPLIERS.OVERTIME_SAVINGS.STANDARD * 100}% / ${MULTIPLIERS.COMP_REDUCTION.STANDARD * 100}%  |  Aggressive: ${MULTIPLIERS.OVERTIME_SAVINGS.AGGRESSIVE * 100}% / ${MULTIPLIERS.COMP_REDUCTION.AGGRESSIVE * 100}%`, margin, y); br(10);
  rule();

  // ---- 4. IMPLEMENTATION ----
  checkBreak(50);
  heading('4. Implementation Plan', 13);

  [
    { phase: 'Phase 1: Days 0–14', items: 'Hardware delivery, install, calibration. Supervisor briefing. Policy update. Unit Champion identification.' },
    { phase: 'Phase 2: Days 15–45', items: 'Utilization ramp, roll-call reminders, Vimocity protocol deployment, peer support activation, usage tracking.' },
    { phase: 'Phase 3: Days 46–90', items: 'Optimization review, interim impact report, leadership debrief, expansion/cancellation recommendation, council brief-out.' },
  ].forEach(p => {
    checkBreak(14);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(37, 99, 235);
    doc.text(p.phase, margin, y); br(5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 80);
    const lines = doc.splitTextToSize(p.items, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 4.5 + 5;
  });
  br(4);
  rule();

  // ---- 5. RISK REGISTER ----
  checkBreak(50);
  heading('5. Risk Register & Mitigation', 13);

  [
    { risk: '"Nap Room" Perception', mit: 'Framed as Readiness Maintenance. Supervisor endorsement. Usage limits documented.' },
    { risk: 'Low Utilization', mit: 'Unit Champions program. Simplified access. Confidentiality separation from disciplinary records.' },
    { risk: 'Privacy / Stigma', mit: 'Third-party managed. No PHI collected. No HR/disciplinary integration.' },
    { risk: 'Overclaiming Outcomes', mit: 'Conservative multipliers. Focus on leading indicators (usage/readiness), not lag indicators (suicide/cancer).' },
    { risk: 'Budget Reallocation', mit: `Year 2+ cost = ${formatCurrency(results.annualTotalCost)} — less than one officer separation.` },
  ].forEach(row => {
    checkBreak(10);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(0);
    doc.text(`Risk: ${row.risk}`, margin, y); br(4);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(70, 70, 90);
    const lines = doc.splitTextToSize(`Mitigation: ${row.mit}`, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 4.5 + 6;
  });
  rule();

  // ---- 6. APPENDIX ----
  checkBreak(50);
  heading('Appendix: Methodology & Inputs', 12);

  const appendixRows: [string, string][] = [
    ['Headcount', String(inputs.headcount)],
    ['Avg Fully Loaded Cost', formatCurrencyFull(inputs.avgFullyLoadedCost || DEFAULTS.AVG_FULLY_LOADED)],
    ['Turnover Rate', `${inputs.turnoverRatePct || DEFAULTS.TURNOVER_RATE}% (${Math.round(inputs.headcount * ((inputs.turnoverRatePct || DEFAULTS.TURNOVER_RATE) / 100))} people/yr)`],
    ['Replacement Cost', formatCurrencyFull(inputs.replacementCostPerPerson || DEFAULTS.REPLACEMENT_COST)],
    ['OT Spend', inputs.annualOvertimeSpend > 0 ? formatCurrencyFull(inputs.annualOvertimeSpend) + ' (actual)' : `Est. at ${DEFAULTS.OT_ESTIMATE_PCT * 100}% of payroll`],
    ['WC Spend', inputs.annualWorkersComp > 0 ? formatCurrencyFull(inputs.annualWorkersComp) + ' (actual)' : `Est. at ${DEFAULTS.WC_ESTIMATE_PCT * 100}% of payroll`],
    ['Liability / Officer', formatCurrencyFull(inputs.liabilityCostPerHead)],
    ['Performance Drag', results.performanceDrag > 0 ? `${formatCurrencyFull(results.performanceDrag)} (payroll × 1–3%)` : 'Excluded — real OT/WC data provided'],
  ];

  appendixRows.forEach(([label, val]) => {
    checkBreak(5);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(80, 80, 100);
    doc.text(label, margin, y);
    doc.setTextColor(0);
    doc.setFont('helvetica', 'bold');
    doc.text(val, margin + 80, y); br(5);
  });

  br(4);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 100, 120);
  doc.text('Sources: PERF 2019 (turnover), BJS LEMAS (OT/turnover rates), RAND (OT recovery), NCCI code 7720 (WC), Journal of Safety Research (fatigue)', margin, y); br(10);

  // ---- DISCLAIMER (footer) ----
  y = pageHeight - 28;
  doc.setDrawColor(200, 200, 220);
  doc.line(margin, y, margin + contentWidth, y); br(4);
  const disc = 'DISCLAIMER: This report estimates potential budget savings based on user inputs and national industry baselines. Results will vary by implementation fidelity. We do not guarantee reductions in lawsuits, workers\' comp claims, or specific medical/legal outcomes. This analysis is for fiscal planning only — not medical, legal, or actuarial advice. All "Avoidable Loss" figures represent recoverable efficiency value, not guaranteed cash savings.';
  doc.setFontSize(7.5);
  doc.setTextColor(130, 130, 150);
  const discLines = doc.splitTextToSize(disc, contentWidth);
  doc.text(discLines, margin, y);

  doc.save(`PIA_Council_Brief_${inputs.profile?.city || 'Agency'}_${new Date().toISOString().split('T')[0]}.pdf`);
};
