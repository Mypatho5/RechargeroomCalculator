import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { AgencyType, LocationProfile, CalculatorInputs } from './types';
import { PRESETS, DEFAULTS, getDefaultLiability, calculateRoomStats } from './constants';
import { ChevronDown, ChevronRight } from 'lucide-react';

const inputStyle: React.CSSProperties = {
  width: '100%',
  height: 44,
  padding: '0 12px',
  background: 'var(--bg)',
  border: '1px solid var(--border)',
  borderRadius: 'var(--radius)',
  color: 'var(--text)',
  fontSize: 14,
  fontFamily: 'var(--font-body)',
  transition: 'border-color 0.15s',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 11,
  fontWeight: 600,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--text-muted)',
  marginBottom: 6,
};

const buildDefaultInputs = (): CalculatorInputs => {
  const rooms = calculateRoomStats(100);
  return {
    agencyType: AgencyType.POLICE,
    headcount: 100,
    locationProfile: LocationProfile.SUBURB,
    annualOvertimeSpend: 0,
    annualTurnoverCount: 0,
    turnoverRatePct: DEFAULTS.TURNOVER_RATE,
    avgFullyLoadedCost: DEFAULTS.AVG_FULLY_LOADED,
    annualWorkersComp: 0,
    replacementCostPerPerson: DEFAULTS.REPLACEMENT_COST,
    liabilityCostPerHead: 650,
    pilotCapex: rooms.pilotCapex,
    pilotRoomOpexAnnual: rooms.pilotRoomOpexAnnual,
    appCostPerUserPerMonth: DEFAULTS.APP_COST_PER_USER_MONTHLY,
    pilotDurationDays: DEFAULTS.PILOT_DURATION_DAYS,
    includePerformanceDrag: false,
    includeAppCost: true,
  };
};

export const QuickCalc: React.FC = () => {
  const navigate = useNavigate();
  const [showDetails, setShowDetails] = useState(false);

  const [inputs, setInputs] = useState<CalculatorInputs>(() => {
    const saved = localStorage.getItem('roi_inputs');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* fall through */ }
    }
    return buildDefaultInputs();
  });

  // Update liability default when profile/agency changes
  useEffect(() => {
    const newDefault = getDefaultLiability(inputs.locationProfile, inputs.agencyType);
    setInputs(prev => ({ ...prev, liabilityCostPerHead: newDefault }));
  }, [inputs.agencyType, inputs.locationProfile]);

  // Update room counts when headcount changes
  useEffect(() => {
    const rooms = calculateRoomStats(inputs.headcount);
    setInputs(prev => ({
      ...prev,
      pilotCapex: rooms.pilotCapex,
      pilotRoomOpexAnnual: rooms.pilotRoomOpexAnnual,
    }));
  }, [inputs.headcount]);

  const set = (field: keyof CalculatorInputs, value: unknown) =>
    setInputs(prev => ({ ...prev, [field]: value }));

  const applyPreset = (preset: typeof PRESETS[0]) => {
    const rooms = calculateRoomStats(preset.data.headcount);
    setInputs(prev => ({
      ...prev,
      ...preset.data,
      pilotCapex: rooms.pilotCapex,
      pilotRoomOpexAnnual: rooms.pilotRoomOpexAnnual,
    }));
  };

  const handleSubmit = () => {
    localStorage.setItem('roi_inputs', JSON.stringify(inputs));
    navigate('/results');
  };

  const hasRealData = inputs.annualOvertimeSpend > 0 || inputs.annualWorkersComp > 0;

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', padding: '48px 24px' }} className="animate-fade-up">

      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 800, color: 'var(--text)', marginBottom: 8 }}>
          Build Your Estimate
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: 15 }}>
          Start with headcount. Add real data for a tighter number.
        </p>
      </div>

      {/* Presets */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 28 }}>
        {PRESETS.map(p => (
          <button
            key={p.name}
            onClick={() => applyPreset(p)}
            style={{
              padding: '12px 14px',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius)',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'border-color 0.15s',
            }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--accent)')}
            onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}
          >
            <span style={{ display: 'block', fontWeight: 700, color: 'var(--accent-bright)', fontSize: 13, marginBottom: 2 }}>{p.name}</span>
            <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>{p.description}</span>
          </button>
        ))}
      </div>

      {/* Main Form */}
      <div style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border)',
        borderRadius: 6,
        padding: '32px',
      }}>

        {/* Row 1 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
          <div>
            <label style={labelStyle}>Agency Type</label>
            <select style={inputStyle} value={inputs.agencyType} onChange={e => set('agencyType', e.target.value)}>
              {Object.values(AgencyType).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Location Profile</label>
            <select style={inputStyle} value={inputs.locationProfile} onChange={e => set('locationProfile', e.target.value)}>
              {Object.values(LocationProfile).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>

        {/* Headcount */}
        <div style={{ marginBottom: 24 }}>
          <label style={labelStyle}>Sworn / Uniformed Headcount</label>
          <input
            type="number"
            style={inputStyle}
            value={inputs.headcount}
            onChange={e => set('headcount', Number(e.target.value))}
            min={1}
          />
          <p style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
            {calculateRoomStats(inputs.headcount).numRooms} Recharge Room{calculateRoomStats(inputs.headcount).numRooms > 1 ? 's' : ''} estimated for this headcount
          </p>
        </div>

        {/* Details Accordion */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20 }}>
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--accent-bright)', fontSize: 12, fontWeight: 700,
              letterSpacing: '0.06em', textTransform: 'uppercase',
              padding: 0, marginBottom: showDetails ? 20 : 0,
            }}
          >
            {showDetails ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
            {showDetails ? 'Hide detailed inputs' : 'Add real data for a tighter estimate (optional)'}
          </button>

          {showDetails && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }} className="animate-fade-in">
              <div>
                <label style={labelStyle}>Annual Turnover (People)</label>
                <input
                  type="number"
                  style={{ ...inputStyle, height: 40 }}
                  value={inputs.annualTurnoverCount || ''}
                  placeholder={`Default: ${Math.round(inputs.headcount * DEFAULTS.TURNOVER_RATE / 100)} (~${DEFAULTS.TURNOVER_RATE}%)`}
                  onChange={e => set('annualTurnoverCount', Number(e.target.value))}
                />
              </div>
              <div>
                <label style={labelStyle}>Annual OT Spend ($)</label>
                <input
                  type="number"
                  style={{ ...inputStyle, height: 40 }}
                  value={inputs.annualOvertimeSpend || ''}
                  placeholder="Leave blank to estimate"
                  onChange={e => set('annualOvertimeSpend', Number(e.target.value))}
                />
              </div>
              <div>
                <label style={labelStyle}>Annual Workers Comp ($)</label>
                <input
                  type="number"
                  style={{ ...inputStyle, height: 40 }}
                  value={inputs.annualWorkersComp || ''}
                  placeholder="Leave blank to estimate"
                  onChange={e => set('annualWorkersComp', Number(e.target.value))}
                />
              </div>
              <div>
                <label style={labelStyle}>Avg Fully Loaded Cost ($)</label>
                <input
                  type="number"
                  style={{ ...inputStyle, height: 40 }}
                  value={inputs.avgFullyLoadedCost}
                  onChange={e => set('avgFullyLoadedCost', Number(e.target.value))}
                />
              </div>

              {/* Performance drag note */}
              {hasRealData && (
                <div style={{
                  gridColumn: '1 / -1',
                  padding: '10px 14px',
                  background: 'var(--bg-raised)',
                  borderLeft: '3px solid var(--accent-dim)',
                  borderRadius: 2,
                  fontSize: 12,
                  color: 'var(--text-muted)',
                }}>
                  <strong style={{ color: 'var(--text)' }}>Performance drag excluded.</strong> Since you've entered real OT and/or Workers Comp data,
                  fatigue-related performance losses are already embedded in those numbers.
                  Adding them again would double-count. This is conservative by design.
                </div>
              )}
            </div>
          )}
        </div>

        {/* App toggle */}
        <div style={{ borderTop: '1px solid var(--border)', marginTop: 24, paddingTop: 20 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={inputs.includeAppCost}
              onChange={e => set('includeAppCost', e.target.checked)}
              style={{ width: 16, height: 16, accentColor: 'var(--accent)' }}
            />
            <div>
              <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>
                Include app cost ($15/user/mo)
              </span>
              <span style={{ display: 'block', fontSize: 11, color: 'var(--text-dim)', marginTop: 2 }}>
                = ${(inputs.headcount * 15 * 12).toLocaleString()}/yr for {inputs.headcount} users — uncheck for rooms-only deals
              </span>
            </div>
          </label>
        </div>

        <div style={{ marginTop: 28 }}>
          <Button size="xl" onClick={handleSubmit} style={{ width: '100%' }}>
            Run Analysis →
          </Button>
          <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-dim)', marginTop: 8 }}>
            Generates a board-ready estimate immediately.
          </p>
        </div>
      </div>
    </div>
  );
};
