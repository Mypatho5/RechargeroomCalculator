import { AgencyType, LocationProfile, CalculatorInputs } from './types';

export const DEFAULTS = {
  // Turnover: PERF (Police Executive Research Forum) 2019 — $150K-$250K range
  // We use $175K as defensible midpoint. Lower than PERF ceiling, above floor.
  REPLACEMENT_COST: 175000,

  AVG_FULLY_LOADED: 120000,

  TURNOVER_RATE: 12, // BJS LEMAS survey median for municipal PD

  // OT: 12% of payroll — BJS Law Enforcement Management & Administrative Statistics
  OT_ESTIMATE_PCT: 0.12,

  // WC: Corrected from 3% to 5% — NCCI class code 7720 (Police) baseline rate
  // before experience modification. 3% was indefensibly low for law enforcement.
  WC_ESTIMATE_PCT: 0.05,

  // Pilot pricing
  ROOM_CAPEX: 50000,       // Per room hardware + install
  ROOM_OPEX_MONTHLY: 1000, // Per room service/support

  // App: $15/user/month
  APP_COST_PER_USER_MONTHLY: 15,

  PILOT_DURATION_DAYS: 90,
};

// Savings multipliers by risk mode
// These are deliberately conservative — designed to survive a CFO challenge
export const MULTIPLIERS = {
  // OT recoverable via fatigue reduction: 5-15% of total OT spend
  // Source: Journal of Safety Research / RAND Police Staffing Studies
  OVERTIME_SAVINGS: { CONSERVATIVE: 0.05, STANDARD: 0.10, AGGRESSIVE: 0.15 },

  // WC reduction via physical recovery + injury prevention: 3-10%
  // Source: NCCI Workplace Wellness Study 2022
  COMP_REDUCTION:   { CONSERVATIVE: 0.03, STANDARD: 0.06, AGGRESSIVE: 0.10 },

  // Performance/absenteeism drag: % of payroll
  // Only applied when no real OT/WC data entered (avoids double-counting)
  // Source: Harvard Business Review / CDC Workplace Productivity
  PRODUCTIVITY_LOSS: { CONSERVATIVE: 0.01, STANDARD: 0.02, AGGRESSIVE: 0.03 },
};

export const getDefaultLiability = (profile: LocationProfile, agency: AgencyType): number => {
  if (profile === LocationProfile.MAJOR_CITY && agency === AgencyType.POLICE) return 8000;
  if (profile === LocationProfile.SUBURB && agency === AgencyType.POLICE) return 650;
  if (profile === LocationProfile.RURAL) return 350;
  return 500;
};

export const calculateRoomStats = (headcount: number) => {
  const numRooms = Math.max(1, Math.ceil(headcount / 100));
  const pilotCapex = numRooms * DEFAULTS.ROOM_CAPEX;
  const pilotRoomOpexAnnual = numRooms * DEFAULTS.ROOM_OPEX_MONTHLY * 12;
  return { numRooms, pilotCapex, pilotRoomOpexAnnual };
};

export const PRESETS = [
  {
    name: 'Chicago PD Style',
    description: 'Major City / 11,700+ Sworn',
    data: {
      agencyType: AgencyType.POLICE,
      headcount: 11720,
      locationProfile: LocationProfile.MAJOR_CITY,
      liabilityCostPerHead: 8000,
    }
  },
  {
    name: 'Glendale PD Style',
    description: 'Suburb / ~468 Sworn',
    data: {
      agencyType: AgencyType.POLICE,
      headcount: 468,
      locationProfile: LocationProfile.SUBURB,
      liabilityCostPerHead: 650,
    }
  },
  {
    name: 'Rural Dept',
    description: 'Small Town / ~35 Officers',
    data: {
      agencyType: AgencyType.MIXED,
      headcount: 35,
      locationProfile: LocationProfile.RURAL,
      liabilityCostPerHead: 350,
    }
  }
];

export const MOCK_INPUTS: CalculatorInputs = {
  agencyType: AgencyType.POLICE,
  headcount: 468,
  locationProfile: LocationProfile.SUBURB,
  annualOvertimeSpend: 1500000,
  annualTurnoverCount: 56,
  turnoverRatePct: 12,
  avgFullyLoadedCost: 120000,
  annualWorkersComp: 3000000,
  replacementCostPerPerson: 175000,
  liabilityCostPerHead: 650,
  pilotCapex: 250000,
  pilotRoomOpexAnnual: 60000,
  appCostPerUserPerMonth: 15,
  pilotDurationDays: 90,
  includePerformanceDrag: false,
  includeAppCost: true,
  isMockData: true,
  profile: {
    departmentName: 'Glendale Police Department (DEMO)',
    city: 'Glendale',
    state: 'AZ',
    contactName: 'Chief Demo',
    contactTitle: 'Chief of Police',
    decisionTimeline: '30-90 days',
    biggestPressure: 'Turnover',
  }
};

export const EVIDENCE = [
  {
    id: 'turnover-1',
    category: 'Turnover Cost',
    title: 'Costs and Benefits of Officer Resignation from Police Departments',
    source: 'Police Executive Research Forum (PERF), 2019',
    url: 'https://www.policeforum.org/assets/docs/Free_Online_Documents/Hiring/retaining%20police%20officers%202019.pdf',
    finding: '$150K–$250K per sworn officer separation, including recruitment, academy, and FTO overlap.'
  },
  {
    id: 'turnover-2',
    category: 'Turnover Rate',
    title: 'Law Enforcement Management and Administrative Statistics (LEMAS)',
    source: 'Bureau of Justice Statistics',
    url: 'https://bjs.ojp.gov/data-collection/lemas',
    finding: 'Median annual sworn officer turnover: 10–14% for municipal departments.'
  },
  {
    id: 'ot-1',
    category: 'Overtime',
    title: 'Police Overtime and Its Causes',
    source: 'RAND Corporation / DOJ',
    url: 'https://www.rand.org/pubs/research_reports/RRA108-10.html',
    finding: 'Sick-call-driven OT is recoverable; burnout intervention reduces OT dependency 8–15%.'
  },
  {
    id: 'wc-1',
    category: 'Workers Comp',
    title: 'NCCI Class Code 7720 — Police Officers',
    source: 'National Council on Compensation Insurance (NCCI)',
    url: 'https://www.ncci.com',
    finding: 'Baseline WC rate for sworn officers: 4–8% of payroll before experience modification.'
  },
  {
    id: 'fatigue-1',
    category: 'Fatigue & Performance',
    title: 'Sleep Deprivation and Decision Making in Law Enforcement',
    source: 'Journal of Safety Research, Vol. 58',
    url: 'https://pubmed.ncbi.nlm.nih.gov/26022352/',
    finding: '24hr wakefulness produces cognitive impairment equivalent to 0.10 BAC. Officers working extended shifts show 3× incident rate.'
  },
  {
    id: 'liability-1',
    category: 'Liability',
    title: 'Police Misconduct Settlement Data',
    source: 'City of Chicago Data Portal',
    url: 'https://data.cityofchicago.org',
    finding: 'Chicago averaged $100M+/year in settlements (2015–2022), yielding ~$8,500/officer/year basis.'
  },
  {
    id: 'wellness-1',
    category: 'Wellness ROI',
    title: 'Workplace Wellness Programs and Health Care Costs',
    source: 'NCCI Workplace Wellness Study, 2022',
    url: 'https://www.ncci.com/Articles/Pages/Insights-Wellness-Research.aspx',
    finding: 'Evidence-based recovery programs show 3–10% WC claim reduction and 5–12% OT reduction in year 1.'
  },
];
