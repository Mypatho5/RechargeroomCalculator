import React, { useEffect, useState } from 'react';
import { Button } from './Button';
import { CalculatorInputs, RiskMode } from './types';
import { calculateROI, formatCurrency, formatCurrencyFull } from './calculations';
import { generateCouncilReport } from './pdfGenerator';
import { DEFAULTS, MULTIPLIERS } from './constants';
import { Download, Mail, ShieldCheck, AlertTriangle, FileCheck } from 'lucide-react';

export const CouncilReport: React.FC = () => {
  const [inputs, setInputs] = useState<CalculatorInputs | null>(null);
  const [mode, setMode] = useState<RiskMode>(RiskMode.CONSERVATIVE);

  useEffect(() => {
    const saved = localStorage.getItem('roi_inputs');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (!parsed.turnoverRatePct) parsed.turnoverRatePct = DEFAULTS.TURNOVER_RATE;
      if (!parsed.replacementCostPerPerson) parsed.replacementCostPerPerson = DEFAULTS.REPLACEMENT_COST;
      if (parsed.includeAppCost === undefined) parsed.includeAppCost = true;
      setInputs(parsed);
    }
  }, []);

  if (!inputs) return <div style={{ padding: 80, textAlign: 'center', color: 'var(--text-muted)' }}>Generating...</div>;

  const results = calculateROI(inputs, mode);
  const profile = inputs.profile;

  const handleDownload = () => generateCouncilReport(inputs, results, mode);

  const handleEmail = () => {
    const body = [
      `${profile?.contactName || 'Leadership'},`,
      ``,
      `I've completed a preliminary fiscal impact analysis for ${profile?.departmentName || inputs.agencyType}.`,
      ``,
      `Based on our headcount of ${inputs.headcount}, we're carrying an estimated ${formatCurrency(results.totalAnnualSavings)} in annual avoidable costs — primarily from turnover, overtime, and liability exposure.`,
      ``,
      `The proposed pilot (${results.numRooms} Recharge Room${results.numRooms > 1 ? 's' : ''} + platform access) runs ${formatCurrency(results.year1TotalCost)} Year 1, with payback in approximately ${results.paybackMonths} months. 5-year net benefit: ${formatCurrency(results.fiveYearNet)}.`,
      ``,
      `I'd like to walk through the full analysis at your earliest convenience. See attached.`,
      ``,
      `Regards,`,
      profile?.contactName || '',
      profile?.contactTitle || '',
    ].join('\n');

    const link = document.createElement('a');
    link.href = `mailto:?subject=Decision Brief: ${profile?.departmentName || 'Readiness Pilot'}&body=${encodeURIComponent(body)}`;
    link.click();
  };

  const sens = [results.sensitivity.conservative, results.sensitivity.standard, results.sensitivity.aggressive];

  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-surface)',
    border: '1px solid var(--border)',
    borderRadius: 4,
    padding: '20px 24px',
  };

  return (
    <div style={{ minHeight: '100vh', padding: '24px 16px', background: 'var(--bg)' }}>
      <div style={{ maxWidth: 900, margin: '0 auto' }}>

        {/* Toolbar */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          background: 'var(--bg-surface)', border: '1px solid var(--border)',
          borderRadius: 4, padding: '12px 20px', marginBottom: 24, flexWrap: 'wrap', gap: 10,
        }} className="no-print">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <ShieldCheck size={16} color="var(--accent-bright)" />
            <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text)' }}>
              Decision Brief
            </span>
            {inputs.isMockData && (
              <span style={{ fontSize: 10, padding: '2px 8px', background: 'var(--bg-raised)', border: '1px solid var(--border-bright)', borderRadius: 2, color: 'var(--text-muted)', letterSpacing: '0.05em' }}>
                DEMO
              </span>
            )}
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            {/* Mode selector */}
            <div style={{ display: 'flex', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 3, overflow: 'hidden' }}>
              {Object.values(RiskMode).map(m => (
                <button key={m} onClick={() => setMode(m)} style={{
                  padding: '5px 12px', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                  textTransform: 'uppercase', border: 'none', cursor: 'pointer',
                  background: mode === m ? 'var(--accent)' : 'transparent',
                  color: mode === m ? '#fff' : 'var(--text-dim)',
                }}>{m}</button>
              ))}
            </div>
            <Button size="sm" variant="secondary" onClick={handleDownload}>
              <Download size={13} style={{ marginRight: 6 }} /> Download PDF
            </Button>
            <Button size="sm" onClick={handleEmail}>
              <Mail size={13} style={{ marginRight: 6 }} /> Email Finance
            </Button>
          </div>
        </div>

        {/* Report Content */}
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 6, overflow: 'hidden' }}>
          <div style={{ padding: '40px 48px' }}>

            {/* Header */}
            <div style={{ borderBottom: '1px solid var(--border)', paddingBottom: 28, marginBottom: 32 }}>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, color: 'var(--text)', marginBottom: 6 }}>
                Pilot Proposal & Fiscal Impact Analysis
              </h1>
              <p style={{ color: 'var(--text-muted)', fontSize: 15, marginBottom: 24 }}>
                Readiness, Retention, and Risk Reduction Strategy
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 20, fontSize: 13 }}>
                {[
                  { label: 'Prepared For', value: profile?.departmentName || 'Agency Leadership', sub: profile?.city ? `${profile.city}, ${profile.state}` : undefined },
                  { label: 'Prepared By', value: 'Project BUILT / PIA', sub: 'Decision Support Team' },
                  { label: 'Requested By', value: profile?.contactName || 'Agency Command', sub: profile?.contactTitle },
                  { label: 'Primary Driver', value: results.primaryDriver, accent: true },
                ].map(item => (
                  <div key={item.label}>
                    <span style={{ display: 'block', fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-dim)', marginBottom: 4 }}>{item.label}</span>
                    <span style={{ display: 'block', fontWeight: 700, color: item.accent ? 'var(--accent-bright)' : 'var(--text)', fontSize: 14 }}>{item.value}</span>
                    {item.sub && <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{item.sub}</span>}
                  </div>
                ))}
              </div>
            </div>

            {/* Decision Ask */}
            <div style={{
              background: 'rgba(37,99,235,0.06)', border: '1px solid rgba(37,99,235,0.2)',
              borderRadius: 4, padding: '24px 28px', marginBottom: 32,
            }}>
              <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <FileCheck size={22} color="var(--accent-bright)" style={{ flexShrink: 0, marginTop: 2 }} />
                <div>
                  <h2 style={{ fontSize: 17, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>
                    Decision: Approve {inputs.pilotDurationDays || 90}-Day Readiness Pilot
                  </h2>
                  <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16, lineHeight: 1.6 }}>
                    Approve procurement of {results.numRooms} Recharge Unit{results.numRooms > 1 ? 's' : ''}{inputs.includeAppCost ? ' and platform access' : ''} to address {results.primaryDriver.toLowerCase()} drag and reduce identified operational losses.
                  </p>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, fontSize: 13 }}>
                    <div>
                      <span style={{ display: 'block', fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>Included in Pilot:</span>
                      <ul style={{ color: 'var(--text-muted)', paddingLeft: 16, lineHeight: 2 }}>
                        <li>Hardware delivery + install ({results.numRooms} Room{results.numRooms > 1 ? 's' : ''})</li>
                        <li>Supervisor training + policy implementation</li>
                        <li>Vimocity physical recovery protocols</li>
                        <li>Confyde peer support platform access</li>
                        <li>Proactive Conversations training</li>
                        <li>Trauma-Informed Leadership certification</li>
                        <li>Monthly utilization + impact reports</li>
                      </ul>
                    </div>
                    <div>
                      <span style={{ display: 'block', fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>Excluded (No Liability):</span>
                      <ul style={{ color: 'var(--text-muted)', paddingLeft: 16, lineHeight: 2 }}>
                        <li>Clinical diagnosis or medical treatment</li>
                        <li>Guaranteed legal outcomes</li>
                        <li>HR / disciplinary system integration</li>
                        <li>PHI collection or storage</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Financial Summary */}
            <section style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20, paddingBottom: 8, borderBottom: '1px solid var(--border)' }}>
                Financial Analysis
              </h2>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 24 }}>
                <StatBox label="Annual Avoidable Loss" value={formatCurrency(results.totalAnnualSavings)} sub="Status quo cost" />
                <StatBox label="Year 1 Investment" value={formatCurrency(results.year1TotalCost)} sub={`${results.numRooms} room${results.numRooms > 1 ? 's' : ''} + platform${inputs.includeAppCost ? ' + app' : ''}`} />
                <StatBox label="CapEx Payback" value={`${results.paybackMonths} mo`} sub={`5-yr net: ${formatCurrency(results.fiveYearNet)}`} accent />
              </div>

              {/* Cost breakdown */}
              <div style={{ ...cardStyle, marginBottom: 20 }}>
                <h4 style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--text-dim)', marginBottom: 14 }}>Investment Detail</h4>
                <table style={{ width: '100%', fontSize: 13, borderCollapse: 'collapse' }}>
                  <tbody>
                    {[
                      { label: `Room Hardware + Install (${results.numRooms} rooms × $${DEFAULTS.ROOM_CAPEX.toLocaleString()})`, value: results.pilotCapex, note: 'One-time CapEx' },
                      { label: `Room Service / Support (${results.numRooms} rooms × $${DEFAULTS.ROOM_OPEX_MONTHLY.toLocaleString()}/mo)`, value: results.roomOpexAnnual, note: 'Annual OpEx' },
                      ...(inputs.includeAppCost ? [{ label: `App Platform (${inputs.headcount} users × $${inputs.appCostPerUserPerMonth || 15}/mo)`, value: results.appCostAnnual, note: 'Annual OpEx' }] : []),
                    ].map((row, i) => (
                      <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                        <td style={{ padding: '8px 0', color: 'var(--text-muted)' }}>{row.label}</td>
                        <td style={{ padding: '8px 0', textAlign: 'right', color: 'var(--text-dim)', fontSize: 11 }}>{row.note}</td>
                        <td style={{ padding: '8px 0', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--text)' }}>{formatCurrencyFull(row.value)}</td>
                      </tr>
                    ))}
                    <tr style={{ borderTop: '2px solid var(--border-bright)' }}>
                      <td style={{ padding: '10px 0', fontWeight: 700, color: 'var(--text)' }}>Total Year 1</td>
                      <td></td>
                      <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--text)', fontSize: 15 }}>{formatCurrencyFull(results.year1TotalCost)}</td>
                    </tr>
                    <tr>
                      <td style={{ padding: '6px 0', color: 'var(--text-muted)', fontSize: 12 }}>Annual Cost (Year 2+)</td>
                      <td></td>
                      <td style={{ padding: '6px 0', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', fontSize: 12 }}>{formatCurrencyFull(results.annualTotalCost)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* 5-Year Table */}
              <div style={cardStyle}>
                <h4 style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--text-dim)', marginBottom: 14 }}>5-Year Budget Projection</h4>
                <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border)' }}>
                      {['Year', 'Gross Savings', 'Total Cost', 'Net Benefit', 'Cumulative'].map(h => (
                        <th key={h} style={{ padding: '6px 8px', textAlign: 'right', fontSize: 10, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {results.fiveYearTable.map(row => (
                      <tr key={row.year} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                        <td style={{ padding: '8px', textAlign: 'right', fontWeight: 700, color: 'var(--text-muted)' }}>Yr {row.year}{row.year === 1 ? '*' : ''}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text)' }}>{formatCurrencyFull(row.grossSavings)}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>({formatCurrencyFull(row.cost)})</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 600, color: row.net >= 0 ? 'var(--green)' : 'var(--red)' }}>{formatCurrencyFull(row.net)}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 700, color: row.cumulative >= 0 ? 'var(--green)' : 'var(--text-muted)' }}>{formatCurrencyFull(row.cumulative)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 8 }}>
                  * Year 1 includes {formatCurrency(results.pilotCapex)} one-time CapEx.
                  Net Benefit = Gross Savings − Total Cost. All figures based on {mode} scenario.
                </p>
              </div>
            </section>

            {/* Sensitivity Table */}
            <section style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20, paddingBottom: 8, borderBottom: '1px solid var(--border)' }}>
                Sensitivity Analysis
              </h2>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border)' }}>
                      {['Scenario', 'Annual Savings', 'Year 1 Net', 'CapEx Payback', '5-Yr Net', '1-Yr ROI †'].map(h => (
                        <th key={h} style={{ padding: '8px 10px', textAlign: 'right', fontSize: 10, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sens.map(row => {
                      const isActive = row.mode === mode;
                      return (
                        <tr key={row.mode} style={{
                          borderBottom: '1px solid var(--border)',
                          background: isActive ? 'var(--accent-glow)' : 'transparent',
                          fontWeight: isActive ? 700 : 400,
                        }}>
                          <td style={{ padding: '10px 10px', textAlign: 'right', color: 'var(--text)' }}>
                            {row.mode}
                            {isActive && <span style={{ marginLeft: 6, fontSize: 9, color: 'var(--accent-bright)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>▲ selected</span>}
                          </td>
                          <td style={{ padding: '10px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text)' }}>{formatCurrency(row.totalAnnualSavings)}</td>
                          <td style={{ padding: '10px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--green)' }}>{formatCurrency(row.netBenefit)}</td>
                          <td style={{ padding: '10px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{row.paybackMonths} mo</td>
                          <td style={{ padding: '10px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--green)' }}>{formatCurrency(row.fiveYearNet)}</td>
                          <td style={{ padding: '10px', textAlign: 'right', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{row.roiPct.toFixed(0)}%</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                <p style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 8 }}>
                  † 1-Yr ROI = (Year 1 Net Benefit) ÷ (Year 1 Total Investment) × 100. Not annualized.
                  Conservative = 5% OT / 3% WC recovery. Standard = 10% / 6%. Aggressive = 15% / 10%.
                </p>
              </div>
            </section>

            {/* Implementation */}
            <section style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20, paddingBottom: 8, borderBottom: '1px solid var(--border)' }}>
                Implementation Plan ({inputs.pilotDurationDays || 90} Days)
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
                {[
                  { phase: 'Phase 1: Days 0–14', title: 'Install & Onboarding', items: ['Hardware delivery + calibration', 'Supervisor briefing', 'Policy update', 'Identify Unit Champions'] },
                  { phase: 'Phase 2: Days 15–45', title: 'Utilization Ramp', items: ['Roll-call reminders', 'Usage metric tracking', 'Vimocity protocol rollout', 'Peer support activation'] },
                  { phase: 'Phase 3: Days 46–90', title: 'Optimization & Review', items: ['Interim impact report', 'Leadership debrief', 'Expansion/cancellation review', 'Council brief-out prep'] },
                ].map(p => (
                  <div key={p.phase} style={{ padding: '16px 18px', border: '1px solid var(--border)', borderRadius: 4, fontSize: 12 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--accent-bright)', marginBottom: 6 }}>{p.phase}</div>
                    <div style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>{p.title}</div>
                    <ul style={{ color: 'var(--text-muted)', paddingLeft: 14, lineHeight: 1.8 }}>
                      {p.items.map(item => <li key={item}>{item}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            </section>

            {/* Risk Register */}
            <section style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20, paddingBottom: 8, borderBottom: '1px solid var(--border)' }}>
                Risk Register
              </h2>
              <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: 'var(--bg-raised)' }}>
                    <th style={{ padding: '10px 14px', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>Risk</th>
                    <th style={{ padding: '10px 14px', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>Mitigation</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { risk: '"Nap Room" Perception', mit: 'Framed strictly as Readiness Maintenance; supervisor endorsement; documented usage limits.' },
                    { risk: 'Low Utilization', mit: 'Unit Champions program; simplified access; confidentiality separation from disciplinary records.' },
                    { risk: 'Privacy / Stigma', mit: 'Third-party managed; no PHI collected; no integration with HR or disciplinary systems.' },
                    { risk: 'Overclaiming Outcomes', mit: 'Report focuses on leading indicators (usage, readiness) not lag indicators (suicide, cancer). Conservative multipliers throughout.' },
                    { risk: 'Budget Reallocation Risk', mit: `Annual cost (Year 2+) is ${formatCurrency(results.annualTotalCost)} — less than the cost of one separation.` },
                  ].map((row, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td style={{ padding: '10px 14px', fontWeight: 600, color: 'var(--text)' }}>{row.risk}</td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-muted)', lineHeight: 1.5 }}>{row.mit}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            {/* Appendix */}
            <section style={{ marginBottom: 32 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 20, paddingBottom: 8, borderBottom: '1px solid var(--border)' }}>
                Appendix: Methodology & Inputs
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, fontSize: 12 }}>
                <div>
                  <h4 style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>Calculated Inputs</h4>
                  {[
                    ['Headcount', inputs.headcount],
                    ['Avg Fully Loaded Cost', formatCurrencyFull(inputs.avgFullyLoadedCost || DEFAULTS.AVG_FULLY_LOADED)],
                    ['Turnover Rate', `${inputs.turnoverRatePct || DEFAULTS.TURNOVER_RATE}% (${Math.round(inputs.headcount * ((inputs.turnoverRatePct || DEFAULTS.TURNOVER_RATE) / 100))} people/yr)`],
                    ['Replacement Cost', formatCurrencyFull(inputs.replacementCostPerPerson || DEFAULTS.REPLACEMENT_COST)],
                    ['OT Spend', inputs.annualOvertimeSpend > 0 ? formatCurrencyFull(inputs.annualOvertimeSpend) + ' (actual)' : `Est. at ${DEFAULTS.OT_ESTIMATE_PCT * 100}% of payroll`],
                    ['WC Spend', inputs.annualWorkersComp > 0 ? formatCurrencyFull(inputs.annualWorkersComp) + ' (actual)' : `Est. at ${DEFAULTS.WC_ESTIMATE_PCT * 100}% of payroll`],
                    ['Liability / Officer', formatCurrencyFull(inputs.liabilityCostPerHead)],
                  ].map(([label, val]) => (
                    <div key={String(label)} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border)', color: 'var(--text-muted)' }}>
                      <span>{label}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text)' }}>{val}</span>
                    </div>
                  ))}
                </div>
                <div>
                  <h4 style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>Formulas</h4>
                  <div style={{ lineHeight: 2, color: 'var(--text-muted)' }}>
                    <p><strong style={{ color: 'var(--text)' }}>Turnover:</strong> Headcount × Rate% × ${(inputs.replacementCostPerPerson || DEFAULTS.REPLACEMENT_COST).toLocaleString()}</p>
                    <p><strong style={{ color: 'var(--text)' }}>OT Savings:</strong> {inputs.annualOvertimeSpend > 0 ? 'Actual OT' : `Payroll × ${DEFAULTS.OT_ESTIMATE_PCT * 100}%`} × Recovery Factor</p>
                    <p><strong style={{ color: 'var(--text)' }}>WC Savings:</strong> {inputs.annualWorkersComp > 0 ? 'Actual WC' : `Payroll × ${DEFAULTS.WC_ESTIMATE_PCT * 100}%`} × Reduction Factor</p>
                    <p><strong style={{ color: 'var(--text)' }}>Liability:</strong> {inputs.headcount} officers × ${inputs.liabilityCostPerHead.toLocaleString()}/officer</p>
                    <p><strong style={{ color: 'var(--text)' }}>Performance:</strong> {results.performanceDrag > 0 ? 'Payroll × 1–3%' : 'Excluded (real OT/WC data provided)'}</p>
                    <p style={{ marginTop: 10, fontSize: 11 }}>
                      Conservative = 5%/3% recovery. Standard = 10%/6%. Aggressive = 15%/10%.
                      Sources: PERF 2019, BJS LEMAS, RAND, NCCI code 7720.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Disclaimer */}
            <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <AlertTriangle size={12} color="var(--text-dim)" />
                <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>Disclaimer</span>
              </div>
              <p style={{ fontSize: 10, color: 'var(--text-dim)', lineHeight: 1.7 }}>
                This report estimates potential budget savings based on user-provided inputs and national industry baselines. Results will vary by implementation fidelity, local labor conditions, and departmental policy.
                <strong> We do not guarantee</strong> reductions in lawsuits, workers' compensation claims, cancer risk, or specific medical outcomes.
                All "Avoidable Loss" figures represent recoverable efficiency value, not guaranteed cash savings.
                This analysis is for fiscal planning and decision support only. It does not constitute medical, legal, or actuarial advice.
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

const StatBox: React.FC<{ label: string; value: string; sub: string; accent?: boolean }> = ({ label, value, sub, accent }) => (
  <div style={{
    background: 'var(--bg-raised)', border: '1px solid var(--border)',
    borderRadius: 4, padding: '18px 20px',
  }}>
    <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-dim)', marginBottom: 6 }}>{label}</div>
    <div style={{ fontSize: 26, fontWeight: 700, fontFamily: 'var(--font-mono)', color: accent ? 'var(--accent-bright)' : 'var(--text)', marginBottom: 4 }}>{value}</div>
    <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{sub}</div>
  </div>
);
