export enum AgencyType {
  POLICE = 'Police',
  FIRE = 'Fire',
  EMS = 'EMS',
  MIXED = 'Mixed'
}

export enum LocationProfile {
  MAJOR_CITY = 'Major City',
  SUBURB = 'Suburb',
  RURAL = 'Rural'
}

export enum RiskMode {
  CONSERVATIVE = 'Conservative',
  STANDARD = 'Standard',
  AGGRESSIVE = 'Aggressive'
}

export interface AgencyProfile {
  departmentName: string;
  city: string;
  state: string;
  contactName: string;
  contactTitle: string;
  decisionTimeline: '0-30 days' | '30-90 days' | '90+ days' | 'Unknown';
  biggestPressure: 'Overtime' | 'Turnover' | 'Liability' | 'Workers Comp' | 'Sleep/Readiness' | 'Other';
}

export interface CalculatorInputs {
  // Core
  agencyType: AgencyType;
  headcount: number;
  locationProfile: LocationProfile;

  // Cost Drivers
  annualOvertimeSpend: number;
  annualTurnoverCount: number;
  turnoverRatePct: number;
  avgFullyLoadedCost: number;
  annualWorkersComp: number;
  replacementCostPerPerson: number; // RENAMED from recruitCost — one field, one name

  // Pilot Costs
  pilotCapex: number;         // Room hardware + install
  pilotRoomOpexAnnual: number; // Room service ($1K/mo/room)
  appCostPerUserPerMonth: number; // $15/user/mo default
  pilotDurationDays: number;

  // Toggles
  includePerformanceDrag: boolean;
  includeAppCost: boolean;    // Toggle for deals without the app

  // Liability
  liabilityCostPerHead: number;

  // Report Profile
  profile?: AgencyProfile;

  // Flags
  isMockData?: boolean;
}

export interface SensitivityResult {
  mode: RiskMode;
  totalAnnualSavings: number;
  annualCost: number;
  netBenefit: number;
  paybackMonths: string;
  fiveYearNet: number;
  roiPct: number;
}

export interface CalculationResult {
  // Savings drivers
  turnoverDrag: number;
  overtimeDrag: number;
  workersCompDrag: number;
  liabilityDrag: number;
  performanceDrag: number;
  totalAnnualSavings: number;

  // Costs
  pilotCapex: number;
  annualTotalCost: number;    // rooms opex + app cost
  year1TotalCost: number;     // capex + annual cost

  // Returns
  netBenefitYear1: number;
  paybackMonths: string;
  fiveYearNet: number;
  fiveYearTable: { year: number; grossSavings: number; cost: number; net: number; cumulative: number }[];

  // Meta
  numRooms: number;
  primaryDriver: string;
  appCostAnnual: number;
  roomOpexAnnual: number;

  sensitivity: {
    conservative: SensitivityResult;
    standard: SensitivityResult;
    aggressive: SensitivityResult;
  };
}

export interface LeadData {
  stage: 'unlocked_results' | 'full_report_submitted';
  email: string;
  agencyType: string;
  headcount: number;
  timestamp: string;
  consent: boolean;
  profile?: AgencyProfile;
}
