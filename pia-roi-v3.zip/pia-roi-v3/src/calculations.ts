import { CalculatorInputs, CalculationResult, RiskMode, SensitivityResult } from './types';
import { MULTIPLIERS, DEFAULTS, calculateRoomStats } from './constants';

export const formatCurrency = (amount: number): string => {
  if (Math.abs(amount) >= 1_000_000) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency', currency: 'USD',
      notation: 'compact', maximumFractionDigits: 2
    }).format(amount);
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD',
    maximumFractionDigits: 0
  }).format(amount);
};

export const formatCurrencyFull = (amount: number): string =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(amount);

// Single-pass scenario calc used for sensitivity analysis
const calcScenario = (inputs: CalculatorInputs, mode: RiskMode): {
  totalAnnualSavings: number;
  turnoverDrag: number;
  overtimeDrag: number;
  workersCompDrag: number;
  liabilityDrag: number;
  performanceDrag: number;
} => {
  const mk = mode.toUpperCase() as keyof typeof MULTIPLIERS.OVERTIME_SAVINGS;
  const salary = inputs.avgFullyLoadedCost || DEFAULTS.AVG_FULLY_LOADED;
  const payroll = inputs.headcount * salary;

  // 1. Turnover
  const effectiveCount = inputs.turnoverRatePct > 0
    ? Math.round(inputs.headcount * (inputs.turnoverRatePct / 100))
    : (inputs.annualTurnoverCount || Math.round(inputs.headcount * (DEFAULTS.TURNOVER_RATE / 100)));
  const replacementCost = inputs.replacementCostPerPerson || DEFAULTS.REPLACEMENT_COST;
  const turnoverDrag = effectiveCount * replacementCost;

  // 2. Overtime
  // Use actual spend if provided, else estimate at 12% of payroll (BJS LEMAS baseline)
  const otSpend = inputs.annualOvertimeSpend > 0
    ? inputs.annualOvertimeSpend
    : payroll * DEFAULTS.OT_ESTIMATE_PCT;
  const overtimeDrag = otSpend * MULTIPLIERS.OVERTIME_SAVINGS[mk];

  // 3. Workers Comp
  // Use actual spend if provided, else estimate at 5% of payroll (NCCI code 7720 baseline)
  // NOTE: 3% was the previous default — corrected upward. Law enforcement WC rates
  // are materially higher than general industry.
  const wcSpend = inputs.annualWorkersComp > 0
    ? inputs.annualWorkersComp
    : payroll * DEFAULTS.WC_ESTIMATE_PCT;
  const workersCompDrag = wcSpend * MULTIPLIERS.COMP_REDUCTION[mk];

  // 4. Liability
  const liabilityDrag = inputs.headcount * inputs.liabilityCostPerHead;

  // 5. Performance / Absenteeism
  // CRITICAL: Only include if user explicitly toggled on, OR if no real OT/WC data entered.
  // When real OT+WC data is provided, fatigue-driven performance drag is already embedded
  // in those numbers. Including it again would double-count. The UI makes this explicit.
  const hasRealCostData = inputs.annualOvertimeSpend > 0 || inputs.annualWorkersComp > 0;
  const shouldIncludePerf = inputs.includePerformanceDrag && !hasRealCostData;
  const performanceDrag = shouldIncludePerf ? payroll * MULTIPLIERS.PRODUCTIVITY_LOSS[mk] : 0;

  const totalAnnualSavings = turnoverDrag + overtimeDrag + workersCompDrag + liabilityDrag + performanceDrag;

  return { totalAnnualSavings, turnoverDrag, overtimeDrag, workersCompDrag, liabilityDrag, performanceDrag };
};

export const calculateROI = (inputs: CalculatorInputs, activeMode: RiskMode): CalculationResult => {
  const roomStats = calculateRoomStats(inputs.headcount);
  const numRooms = inputs.pilotCapex ? Math.max(1, Math.round(inputs.pilotCapex / DEFAULTS.ROOM_CAPEX)) : roomStats.numRooms;
  const pilotCapex = inputs.pilotCapex || roomStats.pilotCapex;

  // Annual costs
  const roomOpexAnnual = inputs.pilotRoomOpexAnnual || roomStats.pilotRoomOpexAnnual;
  const appCostAnnual = inputs.includeAppCost
    ? inputs.headcount * (inputs.appCostPerUserPerMonth || DEFAULTS.APP_COST_PER_USER_MONTHLY) * 12
    : 0;
  const annualTotalCost = roomOpexAnnual + appCostAnnual;
  const year1TotalCost = pilotCapex + annualTotalCost;

  // Main scenario
  const scenario = calcScenario(inputs, activeMode);
  const { totalAnnualSavings, turnoverDrag, overtimeDrag, workersCompDrag, liabilityDrag, performanceDrag } = scenario;

  // Net
  const netBenefitYear1 = totalAnnualSavings - year1TotalCost;

  // Payback: months of annualTotalCost-net savings to recover the capex
  const annualNetOfOpex = totalAnnualSavings - annualTotalCost;
  let paybackMonths = 'N/A';
  if (annualNetOfOpex > 0) {
    paybackMonths = (pilotCapex / (annualNetOfOpex / 12)).toFixed(1);
  }

  // 5-year table
  const fiveYearTable = [];
  let cumulative = 0;
  for (let yr = 1; yr <= 5; yr++) {
    const cost = yr === 1 ? year1TotalCost : annualTotalCost;
    const net = totalAnnualSavings - cost;
    cumulative += net;
    fiveYearTable.push({ year: yr, grossSavings: totalAnnualSavings, cost, net, cumulative });
  }
  const fiveYearNet = fiveYearTable[4].cumulative;

  // Sensitivity
  const buildSensitivity = (m: RiskMode): SensitivityResult => {
    const s = calcScenario(inputs, m);
    const yr1Cost = pilotCapex + annualTotalCost;
    const netYr1 = s.totalAnnualSavings - yr1Cost;
    const annualNet = s.totalAnnualSavings - annualTotalCost;
    let pb = 'N/A';
    if (annualNet > 0) pb = (pilotCapex / (annualNet / 12)).toFixed(1);

    // 5-year net for sensitivity
    let cum5 = 0;
    for (let yr = 1; yr <= 5; yr++) {
      const cost = yr === 1 ? yr1Cost : annualTotalCost;
      cum5 += s.totalAnnualSavings - cost;
    }

    // ROI: standard formula — net benefit year 1 / total year 1 investment
    // Labeled "1-Yr ROI" in UI to avoid confusion with multi-year ROI
    const roi = yr1Cost > 0 ? (netYr1 / yr1Cost) * 100 : 0;

    return {
      mode: m,
      totalAnnualSavings: s.totalAnnualSavings,
      annualCost: annualTotalCost,
      netBenefit: netYr1,
      paybackMonths: pb,
      fiveYearNet: cum5,
      roiPct: roi,
    };
  };

  const sensitivity = {
    conservative: buildSensitivity(RiskMode.CONSERVATIVE),
    standard: buildSensitivity(RiskMode.STANDARD),
    aggressive: buildSensitivity(RiskMode.AGGRESSIVE),
  };

  // Primary driver
  const drivers = { Turnover: turnoverDrag, Overtime: overtimeDrag, Liability: liabilityDrag, 'Workers Comp': workersCompDrag, Performance: performanceDrag };
  const primaryDriver = Object.entries(drivers).reduce((a, b) => a[1] > b[1] ? a : b)[0];

  return {
    turnoverDrag, overtimeDrag, workersCompDrag, liabilityDrag, performanceDrag,
    totalAnnualSavings,
    pilotCapex, annualTotalCost, year1TotalCost,
    netBenefitYear1, paybackMonths, fiveYearNet, fiveYearTable,
    numRooms, primaryDriver, appCostAnnual, roomOpexAnnual,
    sensitivity,
  };
};
